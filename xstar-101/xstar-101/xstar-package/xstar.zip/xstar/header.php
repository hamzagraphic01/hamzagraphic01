<?php
/**
 * The header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package xstar
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="themesflat">
    <link rel="profile" href="https://gmpg.org/xfn/11">

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> <?php echo esc_attr( themesflat_get_opt('layout_theme_style') ); ?>>
    <?php wp_body_open(); ?>
    <div class="themesflat-boxed">
        <div class="header-boxed">
            <?php
			get_template_part( 'tpl/site-header');        		
		?>
        </div>
        <!-- Page Title -->
        <?php get_template_part( 'tpl/page-title'); ?>
        <div id="main-content" class="site-main clearfix ">
            <div id="themesflat-content" class="page-wrap <?php echo esc_attr( themesflat_blog_layout() ); ?> ">
                <?php
			$enable_line_body = themesflat_get_opt('enable_line_body');
			if (themesflat_get_opt_elementor('enable_line_body') != '') {
				$enable_line_body = themesflat_get_opt_elementor('enable_line_body');
			}
			 if ($enable_line_body == 1): ?>
                <div class="line-shape cus-z-1 first">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            <?php endif;