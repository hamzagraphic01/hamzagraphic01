<?php
if ( ! function_exists( 'xstar_child_enqueue_child_styles' ) ) {
	function xstar_child_enqueue_child_styles() {
	    // loading parent style
	    wp_register_style(
	      'xstar-theme-style',
	      get_template_directory_uri() . '/style.css'
	    );

	    wp_enqueue_style( 'xstar-theme-style' );
	    // loading child style
	    wp_register_style(
	      'xstar-child-theme-style',
	      get_stylesheet_directory_uri() . '/style.css'
	    );
	    wp_enqueue_style( 'xstar-child-theme-style');
	 }
}
add_action( 'wp_enqueue_scripts', 'xstar_child_enqueue_child_styles' );

add_theme_support( 'title-tag' );
add_theme_support( 'automatic-feed-links' );
